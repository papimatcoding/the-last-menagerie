window.MENAGERIE_DATA = (() => {
  const sigils = {
    swift:{mark:"I",name:"Preludio",text:"Ataca antes de la resolución normal."},
    venom:{mark:"V",name:"Vitriolo",text:"Si inflige daño a una criatura, esta muere al final del turno."},
    guardian:{mark:"G",name:"Custodia",text:"El primer daño recibido cada turno se reduce en 2."},
    brood:{mark:"O",name:"Descendencia",text:"Al morir deja una Vela 0/2 en su carril."},
    hunger:{mark:"H",name:"Hambre",text:"Al matar una criatura gana +1 Ataque durante la run."},
    echo:{mark:"E",name:"Eco",text:"Al entrar en juego roba una Bestia."},
    thorns:{mark:"T",name:"Espinas",text:"Devuelve 1 de daño al atacante."},
    leech:{mark:"S",name:"Sangría",text:"Cada impacto directo genera 1 Sangre ese turno."},
    ward:{mark:"W",name:"Amparo",text:"Si estaba a vida completa, no puede morir de un solo golpe."},
    requiem:{mark:"R",name:"Réquiem",text:"Al morir empuja 1 Presión a tu favor."},
    duet:{mark:"D",name:"Dúo",text:"Si tiene un aliado adyacente, gana +1 Ataque."},
    precise:{mark:"IV",name:"Compás IV",text:"Si realiza el cuarto impacto de la Cadencia, añade +1 Presión."}
  };

  const beasts = [
    ["ashwing","Polilla de Humo",1,"blood",2,2,["echo"],"Velo","Un insecto ritual atraído por cartas aún no escritas."],
    ["iron_cub","Cachorro de Hierro",1,"blood",2,4,["guardian"],"Hierro","Su piel conserva las marcas de antiguas jaulas."],
    ["glass_adder","Víbora de Vidrio",2,"blood",1,3,["venom"],"Velo","No necesita fuerza cuando una herida puede ser definitiva."],
    ["red_hare","Liebre Roja",1,"blood",3,1,["swift"],"Feral","Una aparición breve. Normalmente, suficiente."],
    ["moss_boar","Jabalí de Musgo",2,"blood",3,5,["thorns"],"Feral","Embiste como si el bosque hubiese aprendido rencor."],
    ["hollow_crow","Cuervo Hueco",3,"bone",4,2,["hunger"],"Velo","Se alimenta de aquello que la mesa decide olvidar."],
    ["saint_shell","Caparazón Santo",4,"bone",1,7,["ward"],"Hierro","Una reliquia viviente construida para negar lo inevitable."],
    ["marrow_wolf","Lobo de Médula",2,"blood",4,3,["leech"],"Feral","No caza por hambre; caza para mantener abierto el ritual."],
    ["blind_weaver","Tejedora Ciega",3,"bone",2,4,["brood"],"Velo","Sus crías aparecen donde antes hubo una muerte."],
    ["threshold_stag","Ciervo del Umbral",3,"blood",5,6,["guardian"],"Feral","El guardián de un límite que nadie recuerda haber cruzado."],
    ["bell_golem","Gólem de Campana",5,"bone",4,8,["thorns"],"Hierro","Cada impacto hace vibrar una campana que no está presente."],
    ["ink_owl","Búho de Tinta",3,"blood",3,5,["echo","swift"],"Velo","Lee el siguiente gesto antes de que la mano lo ejecute."],
    ["solar_hyena","Hiena Solar",4,"bone",3,4,["hunger","duet"],"Feral","Ríe solo cuando otra criatura ha abierto el compás."],
    ["rune_crab","Cangrejo Rúnico",1,"blood",1,5,["guardian"],"Hierro","Las runas de su caparazón cambian al recibir daño."],
    ["black_ram","Carnero Negro",3,"blood",6,4,["leech"],"Feral","Una línea recta convertida en animal."],
    ["veil_lynx","Lince del Velo",2,"blood",3,3,["swift","precise"],"Velo","Aparece únicamente cuando la escena necesita una ejecución."],
    ["choir_eel","Anguila del Coro",3,"bone",2,5,["duet","echo"],"Velo","Su cuerpo vibra con la presencia de aliados próximos."],
    ["ivory_mantis","Mantis de Marfil",2,"blood",4,2,["swift","venom"],"Hierro","La precisión de una herramienta a la que se permitió tener hambre."],
    ["lantern_fox","Zorro de Farol",2,"blood",3,4,["requiem"],"Velo","Su muerte ilumina el lugar exacto donde debe continuar la obra."],
    ["salt_hound","Sabueso de Sal",3,"blood",4,5,["duet"],"Feral","Persigue el rastro mineral que dejan las heridas viejas."],
    ["mirror_swan","Cisne Espejo",4,"bone",3,6,["ward","echo"],"Velo","Su reflejo parece conocer una versión mejor del combate."],
    ["ash_beetle","Escarabajo de Ceniza",2,"bone",1,6,["requiem","guardian"],"Hierro","Recoge restos del ritual hasta que su peso se vuelve defensa."],
    ["thorn_elk","Alce de Espinas",3,"blood",4,7,["thorns","duet"],"Feral","Una arquitectura de ramas diseñada para castigar el contacto."],
    ["mourning_bat","Murciélago de Luto",2,"bone",3,2,["swift","requiem"],"Velo","Cada descenso suyo parece el final de una frase."],
    ["pale_seraph","Serafín Pálido",5,"bone",5,7,["ward","precise"],"Velo","No existe constancia de que haya sido capturado con vida."],
    ["grave_mole","Topo Sepulcral",2,"bone",2,6,["guardian","brood"],"Hierro","Excava debajo de la mesa y regresa con algo que no estaba allí."],
    ["cinder_viper","Víbora de Ascua",2,"blood",3,2,["venom","requiem"],"Feral","La mordedura y la muerte forman parte del mismo movimiento."],
    ["porcelain_ape","Simio de Porcelana",4,"bone",5,5,["hunger","guardian"],"Hierro","Cada fractura visible demuestra que ya sobrevivió a otra escena."]
  ].map(([id,name,cost,costType,atk,hp,sigilsList,tribe,lore])=>({id,name,cost,costType,atk,hp,sigils:sigilsList,tribe,lore,art:`assets/creatures/${id}.svg`}));

  const oaths = [
    {id:"collector",name:"El Conservador",mark:"C",text:"La primera captura repetida de cada Acto despierta dos veces a una carta existente.",flavor:"Favorece un reparto pequeño, veterano y cada vez más singular."},
    {id:"butcher",name:"El Sacrificador",mark:"S",text:"El primer sacrificio de cada turno produce una Sangre adicional.",flavor:"Convierte la propia mesa en economía y acelera criaturas de Sangre."},
    {id:"scribe",name:"El Dramaturgo",mark:"D",text:"Tus cartas necesitan una baja menos para Despertar.",flavor:"Hace que las criaturas concretas desarrollen identidad con mayor rapidez."}
  ];

  const relics = [
    {id:"ivory_tooth",mark:"◇",name:"Diente de Marfil",text:"El primer impacto directo de cada turno genera +1 Presión adicional."},
    {id:"broken_bell",mark:"◌",name:"Campana Hendida",text:"La primera criatura de coste 1 jugada cada turno recibe +1 Ataque."},
    {id:"empty_cage",mark:"▥",name:"Jaula Vacía",text:"El límite de mano aumenta de 6 a 7."},
    {id:"borrowed_heart",mark:"♥",name:"Corazón Prestado",text:"Comienzas cada combate con una segunda Vela."},
    {id:"bone_needle",mark:"†",name:"Aguja de Hueso",text:"Los Injertos también conceden +1 Vida al huésped."},
    {id:"black_ash",mark:"✦",name:"Ceniza Negra",text:"Después de una Victoria Alfa, una carta aleatoria obtiene 1 memoria de baja."},
    {id:"half_moon",mark:"☾",name:"Media Luna",text:"Cada tercera carta jugada cuesta 1 recurso menos."},
    {id:"ancient_jaw",mark:"⌁",name:"Mandíbula Antigua",text:"Comienzas cada combate con 2 Huesos."},
    {id:"fourth_string",mark:"IV",name:"Cuarta Cuerda",text:"La Cadenza añade +3 Presión en lugar de +2."},
    {id:"silver_mirror",mark:"□",name:"Espejo de Plata",text:"La primera criatura que Despierta en un combate recupera toda su Vida."},
    {id:"red_thread",mark:"—",name:"Hilo Carmesí",text:"La primera criatura con Dúo que juegues obtiene además +1 Vida."},
    {id:"sealed_program",mark:"§",name:"Programa Sellado",text:"Tras un Guardián, puedes rechazar la Reliquia y Despertar dos cartas distintas."}
  ];

  const bosses = [
    {id:"taxidermist",name:"EL TAXIDERMISTA",rule:"La primera criatura enemiga que muere en cada carril regresa una vez como copia 1/1.",quote:"«La conservación es solo otra forma de negarse a terminar.»",pool:["threshold_stag","hollow_crow","saint_shell"]},
    {id:"silk_mother",name:"LA MADRE DE SEDA",rule:"Cada dos turnos coloca una Cría en una intención vacía.",quote:"«Ningún espacio permanece vacío si se espera el tiempo suficiente.»",pool:["blind_weaver","glass_adder","ashwing"]},
    {id:"bell_man",name:"EL HOMBRE CAMPANA",rule:"Al final del turno, el carril central recibe 1 de daño en ambos lados.",quote:"«Incluso el dolor puede obedecer a un compás.»",pool:["bell_golem","iron_cub","rune_crab"]},
    {id:"hungry_one",name:"EL HAMBRIENTO",rule:"Cada muerte fortalece en +1 Ataque a su criatura viva más fuerte.",quote:"«Toda forma perfecta necesita algo que consumir.»",pool:["marrow_wolf","solar_hyena","black_ram"]},
    {id:"mirror_choir",name:"EL CORO DEL ESPEJO",rule:"Las criaturas de los carriles laterales copian el Ataque actual del centro al entrar.",quote:"«La simetría no es belleza. Es obediencia.»",pool:["mirror_swan","choir_eel","ink_owl"]},
    {id:"pale_director",name:"EL DIRECTOR PÁLIDO",rule:"Cada cuarto impacto directo del enemigo activa su propia Cadenza.",quote:"«No eres el único que ha aprendido a contar hasta cuatro.»",pool:["pale_seraph","veil_lynx","ivory_mantis"]}
  ];

  const nodeTypes = {
    hunt:{name:"Encuentro",mark:"I",desc:"Combate estándar. La victoria permite capturar una criatura derrotada.",reward:"Captura · Fragmentos"},
    alpha:{name:"Encuentro Alfa",mark:"A",desc:"El rival comienza con ventaja de Presión y criaturas más desarrolladas.",reward:"Captura Alfa · más Fragmentos"},
    graft:{name:"Anatomía",mark:"†",desc:"Destruye una carta y transfiere uno de sus Sigilos a otra.",reward:"Injerto permanente"},
    camp:{name:"Camerino",mark:"C",desc:"Trata una Herida, acelera un Despertar o depura el reparto.",reward:"Recuperación"},
    archive:{name:"Archivo",mark:"§",desc:"Examina tres cartas del reparto y mejora la memoria de una.",reward:"Memoria / información"},
    merchant:{name:"Intermediario",mark:"M",desc:"Gasta Fragmentos de la run en cartas, curas o transformaciones.",reward:"Compra selectiva"},
    altar:{name:"Altar",mark:"V",desc:"Acepta una desventaja permanente a cambio de poder inmediato.",reward:"Pacto"},
    omen:{name:"Presagio",mark:"?",desc:"Un evento narrativo con consecuencias no completamente visibles.",reward:"Variable"},
    reliquary:{name:"Relicario Menor",mark:"R",desc:"Elige entre una reliquia temporal de Acto o Fragmentos.",reward:"Reliquia temporal"},
    boss:{name:"Guardián",mark:"IV",desc:"Cierra el Acto. Su regla altera el combate.",reward:"Reliquia mayor · Captura"}
  };

  const actNames = [
    ["LA GALERÍA VACÍA","Los marcos han sido preparados para criaturas que aún no existen."],
    ["EL AVIARIO CARMESÍ","Cada jaula contiene una sombra distinta del mismo pájaro."],
    ["LA CAPILLA DE SAL","Las heridas no cicatrizan aquí; adquieren forma."],
    ["EL TEATRO SUMERGIDO","El telón abre hacia un lugar que no debería tener profundidad."],
    ["LA SALA SIN PÚBLICO","La obra continúa aunque ya no quede nadie a quien convencer."],
    ["EL CUARTO ESCENARIO","No figura en ningún plano. Sin embargo, siempre estuvo reservado."]
  ];

  const curatorLines = [
    "Una baraja excelente no contiene respuestas. Contiene intenciones.",
    "La criatura que sobreviva suficiente tiempo terminará escribiendo su propio nombre.",
    "Sacrificar no consiste en perder una pieza. Consiste en decidir qué parte de la escena importa menos.",
    "La simetría es útil. La ruptura de la simetría es memorable.",
    "Una carta repetida es una oportunidad para profundizar, no para acumular.",
    "La presión no mide daño. Mide quién está dictando el ritmo de la mesa.",
    "Toda run debería producir al menos una criatura que no pudiera haber existido al principio."
  ];

  return {sigils,beasts,oaths,relics,bosses,nodeTypes,actNames,curatorLines};
})();