(() => {
  const D = window.MENAGERIE_DATA;
  const $ = s => document.querySelector(s);
  const SAVE = "menagerie_directors_cut_v1";
  let meta = JSON.parse(localStorage.getItem(SAVE) || '{"bestDepth":0,"bestBoss":0,"ash":0,"sound":false,"mementos":{}}');
  meta.mementos ||= {};
  let run = null, battle = null, selected = -1, sacrificeMode = false, busy = false, audioCtx = null;

  const beastById = Object.fromEntries(D.beasts.map(x => [x.id,x]));
  const stateScreens = ["menuScreen","oathScreen","mapScreen","battleScreen","deathScreen"];
  const roman = n => ["0","I","II","III","IV","V","VI","VII","VIII","IX","X"][Math.min(10,n)] || String(n);
  const rand = a => a[(Math.random()*a.length)|0];
  const uid = () => Math.random().toString(36).slice(2)+Date.now().toString(36);
  function shuffle(a){for(let i=a.length-1;i>0;i--){const j=(Math.random()*(i+1))|0;[a[i],a[j]]=[a[j],a[i]]}return a}

  function persist(){localStorage.setItem(SAVE,JSON.stringify(meta));renderMenu()}
  function show(id){stateScreens.forEach(x=>$("#"+x).classList.add("hidden"));$("#"+id).classList.remove("hidden")}
  function renderMenu(){
    $("#bestDepth").textContent=meta.bestDepth||0;$("#bestBoss").textContent=meta.bestBoss||0;$("#metaAsh").textContent=meta.ash||0;
    $("#soundBtn").textContent="SONIDO: "+(meta.sound?"SÍ":"NO")
  }
  function modal(title,html){$("#modal").innerHTML=`<div class="panel"><div class="eyebrow">${title}</div>${html}</div>`;$("#modal").classList.remove("hidden")}
  function closeModal(){$("#modal").classList.add("hidden")}
  function wait(ms){return new Promise(r=>setTimeout(r,ms))}
  function toast(t){const x=$("#toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),1000)}
  function displayAtk(c){
    let atk=Math.max(0,c.atk-(c.scar||0));
    if(c.sigils.includes("duet") && battle){
      const side=battle.player.includes(c)?battle.player:battle.enemy;
      const i=side.indexOf(c);
      if((i>0&&side[i-1])||(i<2&&side[i+1])) atk++;
    }
    return atk
  }
  function cardFrom(id){
    const s=beastById[id];
    return {uid:uid(),species:id,name:s.name,cost:s.cost,costType:s.costType,atk:s.atk,hp:s.hp,maxHp:s.hp,sigils:[...s.sigils],tribe:s.tribe,lore:s.lore,kills:0,wake:0,scar:0}
  }
  function candle(hp=1){return{uid:uid(),species:"candle",name:"Vela Votiva",cost:0,costType:"blood",atk:0,hp,maxHp:hp,sigils:[],tribe:"Ofrenda",lore:"Una vida mínima, ofrecida para poner el ritual en movimiento.",kills:0,wake:0,scar:0,isCandle:true}}
  const clone = c => JSON.parse(JSON.stringify(c));
  function wakeNeed(c){return Math.max(2,3+(c.wake||0)-(run?.oath==="scribe"?1:0))}
  function awaken(c){
    c.wake=(c.wake||0)+1;c.kills=0;
    if(c.wake%2){c.atk++;c.maxHp++;c.hp=c.maxHp}
    else{
      const pool=Object.keys(D.sigils).filter(s=>!c.sigils.includes(s));
      if(pool.length)c.sigils.push(rand(pool))
    }
  }
  function hasRelic(id){return run?.relics?.some(r=>r.id===id)}
  function handMax(){return hasRelic("empty_cage")?7:6}

  // FX
  const fx=$("#fx"),ctx=fx.getContext("2d");let particles=[];
  function resizeFx(){const d=Math.min(devicePixelRatio||1,2);fx.width=innerWidth*d;fx.height=innerHeight*d;fx.style.width=innerWidth+"px";fx.style.height=innerHeight+"px";ctx.setTransform(d,0,0,d,0,0)}
  addEventListener("resize",resizeFx);resizeFx();
  function burst(x,y,color="#d2b174",n=12){for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,s=.7+Math.random()*2.4;particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-.7,life:.55+Math.random()*.4,r:.8+Math.random()*1.7,color})}}
  (function drawFx(){ctx.clearRect(0,0,innerWidth,innerHeight);for(const p of particles){p.x+=p.vx;p.y+=p.vy;p.vy+=.018;p.life-=.017;ctx.globalAlpha=Math.max(0,p.life);ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill()}ctx.globalAlpha=1;particles=particles.filter(p=>p.life>0);requestAnimationFrame(drawFx)})();
  function center(el){const r=el.getBoundingClientRect();return{x:r.left+r.width/2,y:r.top+r.height/2}}
  function floatText(el,text,color="#ecd09b"){if(!el)return;const r=el.getBoundingClientRect(),d=document.createElement("div");d.className="float-text";d.textContent=text;d.style.color=color;d.style.left=(r.left+r.width/2)+"px";d.style.top=(r.top+r.height/2)+"px";$("#app").appendChild(d);setTimeout(()=>d.remove(),730)}
  function sfx(kind){
    if(!meta.sound)return;
    try{
      audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();
      const cfg={play:[280,.05],hit:[105,.06],sac:[75,.09],chime:[720,.18],boss:[58,.28],click:[420,.025]}[kind]||[300,.04];
      const o=audioCtx.createOscillator(),g=audioCtx.createGain(),now=audioCtx.currentTime;
      o.frequency.setValueAtTime(cfg[0],now);if(kind==="chime")o.frequency.exponentialRampToValueAtTime(980,now+cfg[1]);
      g.gain.setValueAtTime(.0001,now);g.gain.exponentialRampToValueAtTime(.04,now+.008);g.gain.exponentialRampToValueAtTime(.0001,now+cfg[1]);
      o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(now+cfg[1]+.02)
    }catch{}
  }

  // Menu / run
  $("#soundBtn").onclick=()=>{meta.sound=!meta.sound;persist();sfx("click")};
  $("#newRunBtn").onclick=()=>openOaths();
  $("#restartBtn").onclick=()=>openOaths();
  $("#homeBtn").onclick=()=>show("menuScreen");
  $("#rulesBtn").onclick=openRules;
  $("#backstageBtn").onclick=openBackstage;
  $("#deckBtn").onclick=()=>openDeck();
  $("#inspectBtn").onclick=()=>openBattleHelp();

  function openOaths(){
    show("oathScreen");const g=$("#oathGrid");g.innerHTML="";
    for(const o of D.oaths){
      const d=document.createElement("div");d.className="choice";
      d.innerHTML=`<div class="mark">${o.mark}</div><div class="meta">Juramento</div><h3>${o.name}</h3><p>${o.text}</p><p style="margin-top:7px;color:#8f826f">${o.flavor}</p>`;
      d.onclick=()=>beginRun(o.id);g.appendChild(d)
    }
  }
  function beginRun(oath){
    run={oath,depth:1,act:1,bosses:0,fragments:0,relics:[],deck:[],map:null,currentNode:"start",cleared:[]};
    ["ashwing","iron_cub","red_hare","moss_boar","hollow_crow","rune_crab","marrow_wolf","lantern_fox"].forEach(id=>run.deck.push(cardFrom(id)));
    if(meta.mementos.memory){const c=rand(run.deck);c.kills=1}
    generateActMap();renderMap();show("mapScreen")
  }

  // Map
  const positions = [
    [{x:180,y:552,id:"start"}],
    [{x:70,y:465},{x:180,y:465},{x:290,y:465}],
    [{x:70,y:375},{x:180,y:375},{x:290,y:375}],
    [{x:70,y:285},{x:180,y:285},{x:290,y:285}],
    [{x:70,y:195},{x:180,y:195},{x:290,y:195}],
    [{x:180,y:88,id:"boss"}]
  ];
  function randomNodeType(row){
    const pools=[
      ["hunt","hunt","camp","archive","merchant","omen"],
      ["hunt","alpha","graft","camp","archive","merchant","altar","omen"],
      ["hunt","alpha","graft","camp","merchant","altar","reliquary","omen"]
    ];
    return rand(pools[Math.min(2,Math.floor(row/2))])
  }
  function generateActMap(){
    const nodes=[],edges=[];
    nodes.push({id:"start",row:0,col:0,type:"start",x:180,y:552,done:true});
    for(let r=1;r<=4;r++){
      for(let c=0;c<3;c++)nodes.push({id:`r${r}c${c}`,row:r,col:c,type:randomNodeType(r),x:positions[r][c].x,y:positions[r][c].y,done:false})
    }
    nodes.push({id:"boss",row:5,col:0,type:"boss",x:180,y:88,done:false});
    // Connect start to two random first-row nodes.
    for(const c of shuffle([0,1,2]).slice(0,2))edges.push(["start",`r1c${c}`]);
    // Each row node gets 1-2 plausible forward connections; guarantee all next nodes have at least one incoming.
    for(let r=1;r<4;r++){
      const incoming=new Set();
      for(let c=0;c<3;c++){
        let opts=[c];
        if(c>0)opts.push(c-1);if(c<2)opts.push(c+1);
        opts=shuffle(opts);
        const take=Math.random()<.55?2:1;
        for(const nc of opts.slice(0,take)){edges.push([`r${r}c${c}`,`r${r+1}c${nc}`]);incoming.add(nc)}
      }
      for(let nc=0;nc<3;nc++)if(!incoming.has(nc)){
        const pc=Math.max(0,Math.min(2,nc+(Math.random()<.5?-1:1)));
        edges.push([`r${r}c${pc}`,`r${r+1}c${nc}`])
      }
    }
    for(let c=0;c<3;c++)edges.push([`r4c${c}`,"boss"]);
    run.map={nodes,edges}
  }
  function getNode(id){return run.map.nodes.find(n=>n.id===id)}
  function availableNodes(){
    return run.map.edges.filter(e=>e[0]===run.currentNode).map(e=>e[1]).filter(id=>!run.cleared.includes(id))
  }
  function renderMap(){
    const act=D.actNames[(run.act-1)%D.actNames.length];
    $("#actNum").textContent=roman(run.act);$("#fragTxt").textContent=run.fragments;
    $("#actCard").innerHTML=`<div class="roman">${roman(run.act)}</div><div class="eyebrow">Acto ${roman(run.act)} · Profundidad ${run.depth}</div><h2>${act[0]}</h2><p>${act[1]}</p>`;
    $("#curatorLine").textContent=rand(D.curatorLines);
    const svg=$("#pathSvg"),layer=$("#nodeLayer");svg.innerHTML="";layer.innerHTML="";
    for(const [a,b] of run.map.edges){
      const na=getNode(a),nb=getNode(b),line=document.createElementNS("http://www.w3.org/2000/svg","line");
      line.setAttribute("x1",na.x);line.setAttribute("y1",na.y);line.setAttribute("x2",nb.x);line.setAttribute("y2",nb.y);
      if(run.cleared.includes(a)||a==="start")line.classList.add("reached");
      svg.appendChild(line)
    }
    const avail=new Set(availableNodes());
    for(const n of run.map.nodes){
      if(n.id==="start")continue;
      const wrap=document.createElement("div");wrap.className="map-node";
      if(n.type==="boss")wrap.classList.add("boss");
      if(run.cleared.includes(n.id))wrap.classList.add("done");
      else if(avail.has(n.id))wrap.classList.add("available");
      else wrap.classList.add("locked");
      wrap.style.left=(n.x/360*100)+"%";wrap.style.top=(n.y/600*100)+"%";
      const info=D.nodeTypes[n.type],btn=document.createElement("button");btn.textContent=info.mark;btn.disabled=!avail.has(n.id);
      btn.onclick=()=>chooseMapNode(n.id);
      const label=document.createElement("span");label.textContent=info.name;
      wrap.append(btn,label);layer.appendChild(wrap)
    }
  }
  function chooseMapNode(id){
    const n=getNode(id);run.currentNode=id;
    if(n.type==="boss")return startBattle("boss");
    if(n.type==="hunt"||n.type==="alpha")return startBattle(n.type);
    if(n.type==="graft")return graftEvent(id);
    if(n.type==="camp")return campEvent(id);
    if(n.type==="archive")return archiveEvent(id);
    if(n.type==="merchant")return merchantEvent(id);
    if(n.type==="altar")return altarEvent(id);
    if(n.type==="omen")return omenEvent(id);
    if(n.type==="reliquary")return reliquaryEvent(id)
  }
  function clearNodeAndReturn(id=run.currentNode){
    if(!run.cleared.includes(id))run.cleared.push(id);
    run.depth++;
    meta.bestDepth=Math.max(meta.bestDepth||0,run.depth);persist();
    renderMap();show("mapScreen")
  }
  function advanceAct(){
    run.cleared=[];run.currentNode="start";run.act++;run.depth++;
    run.tempGuardian=false;run.tempCadence=false;run.tempBone=false;run.cadencePact=false;
    generateActMap();meta.bestDepth=Math.max(meta.bestDepth||0,run.depth);persist();
    renderMap();show("mapScreen")
  }

  // Battle
  function startBattle(type){
    selected=-1;sacrificeMode=false;busy=false;
    const isBoss=type==="boss",alpha=type==="alpha";
    const boss=isBoss?D.bosses[(run.act-1)%D.bosses.length]:null;
    const pool=isBoss?boss.pool:D.beasts.map(x=>x.id);
    const enemyDeck=[];
    const count=isBoss?10:7+Math.min(6,Math.floor(run.depth/4));
    for(let i=0;i<count;i++){
      const c=cardFrom(rand(pool)),boost=Math.floor(run.depth/8)+(alpha?1:0);
      c.atk+=boost;c.maxHp+=boost;c.hp=c.maxHp;
      if((alpha||run.depth>10)&&Math.random()<.25)awaken(c);
      enemyDeck.push(c)
    }
    battle={
      type,turn:1,pressure:alpha?(run.cadencePact?-2:-1):0,blood:0,
      bones:(hasRelic("ancient_jaw")?2:0)+(meta.mementos.bone?1:0)+(run.tempBone?1:0)+(run.bonePact?2:0),cadence:0,
      player:[null,null,null],enemy:[null,null,null],queue:[null,null,null],draw:shuffle(run.deck.map(clone)),discard:[],hand:[],
      enemyDeck:shuffle(enemyDeck),defeated:[],drawPending:false,played:0,toothUsed:false,butcherUsed:false,bellUsed:false,
      boss,bossMemory:new Set(),lastBones:0,enemyCadence:0,bloodPactUsed:false,tempCadenceUsed:false
    };
    for(let i=0;i<3;i++)if(battle.enemyDeck.length&&(isBoss||Math.random()<.72))battle.enemy[i]=battle.enemyDeck.pop();
    refillQueue();starterHand();if(hasRelic("borrowed_heart"))battle.hand.push(candle());
    if(meta.mementos.match&&battle.hand.length<handMax())battle.hand.push(candle());
    $("#battleTitle").textContent=isBoss?boss.name:(alpha?"ENCUENTRO ALFA":"ENCUENTRO");
    show("battleScreen");renderBattle();
    scene(isBoss?`ACTO ${roman(run.act)} · GUARDIÁN`:`ACTO ${roman(run.act)} · ENCUENTRO`,
      isBoss?boss.name:(alpha?"ENCUENTRO ALFA":"ENCUENTRO"),
      isBoss?boss.quote:rand(D.curatorLines),
      isBoss?boss.rule:"Domina la Presión. Cada cuarto impacto directo activa la Cadenza."
    )
  }
  function starterHand(){
    const i=battle.draw.findIndex(c=>c.costType==="blood"&&c.cost===1);
    if(i>=0)battle.hand.push(battle.draw.splice(i,1)[0]);
    drawBeast(2);battle.hand.push(candle())
  }
  function drawBeast(n=1){
    while(n--&&battle.hand.length<handMax()){
      if(!battle.draw.length){if(!battle.discard.length)break;battle.draw=shuffle(battle.discard.splice(0))}
      battle.hand.push(battle.draw.pop())
    }
  }
  function effectiveCost(c){
    let cost=c.cost||0;
    if(hasRelic("half_moon")&&(battle.played+1)%3===0)cost=Math.max(0,cost-1);
    if(run.bloodPact && c.costType==="blood" && !battle.bloodPactUsed && !c.isCandle)cost=Math.max(0,cost-1);
    return cost
  }
  function canPay(c){const cost=effectiveCost(c);return c.costType==="bone"?battle.bones>=cost:battle.blood>=cost}
  function renderBattle(){
    $("#bloodTxt").textContent=battle.blood;$("#bonesTxt").textContent=battle.bones;$("#turnTxt").textContent="Turno "+battle.turn;
    const pct=(battle.pressure+7)/14*100;$("#pressureKnob").style.left=pct+"%";
    const f=$("#pressureFill");
    if(battle.pressure>=0){f.style.left="50%";f.style.width=(battle.pressure/14*100)+"%";f.style.background="linear-gradient(90deg,#846944,#d2b16f)"}
    else{f.style.left=pct+"%";f.style.width=(-battle.pressure/14*100)+"%";f.style.background="linear-gradient(90deg,#ac444d,#682932)"}
    const cad=$("#cadence");cad.innerHTML="";for(let i=0;i<4;i++){const d=document.createElement("span");d.className="beat"+(i<battle.cadence?" on":"");cad.appendChild(d)}
    renderSides();renderHand();renderContext()
  }
  function cardHTML(c,enemy=false){
    const marks=c.sigils.slice(0,3).map(s=>`<span class="sigil">${D.sigils[s]?.mark||"?"}</span>`).join("");
    const art=c.isCandle?"assets/creatures/candle.svg":beastById[c.species].art;
    return `<div class="unit-card ${enemy?"enemy":""}">
      <div class="sigils">${marks}</div>${c.wake?`<div class="wake">ACTO ${roman(c.wake)}</div>`:""}
      <div class="unit-art"><img src="${art}" alt=""></div>
      <div class="unit-name">${c.name}</div>
      <div class="unit-meta">${c.tribe}${c.scar?" · HERIDA":""}</div>
      <div class="unit-stats"><span>ATQ ${displayAtk(c)}</span><span>VID ${Math.max(0,c.hp)}</span></div>
    </div>`
  }
  function renderSides(){
    const e=$("#enemySide"),p=$("#playerSide");e.innerHTML="";p.innerHTML="";
    for(let i=0;i<3;i++){
      const lane=document.createElement("div");lane.className="lane";
      if(battle.queue[i]){
        const art=beastById[battle.queue[i].species]?.art||"assets/creatures/candle.svg";
        lane.innerHTML=`<div class="intent"><img src="${art}" alt=""><span>PRÓXIMA</span></div>`
      }
      if(battle.enemy[i])lane.insertAdjacentHTML("beforeend",cardHTML(battle.enemy[i],true));
      e.appendChild(lane)
    }
    for(let i=0;i<3;i++){
      const lane=document.createElement("div");lane.className="lane";
      if(sacrificeMode&&battle.player[i])lane.classList.add("sacrifice");
      else if(selected>=0&&!battle.player[i]&&canPay(battle.hand[selected]))lane.classList.add("ready");
      if(battle.player[i])lane.innerHTML=cardHTML(battle.player[i],false);
      lane.onclick=()=>onLane(i);p.appendChild(lane)
    }
  }
  function renderHand(){
    const h=$("#hand");h.innerHTML="";
    battle.hand.forEach((c,i)=>{
      const cost=effectiveCost(c),pay=canPay(c),art=c.isCandle?"assets/creatures/candle.svg":beastById[c.species].art,d=document.createElement("div");
      d.className="hand-card"+(selected===i?" selected":"")+(!pay&&cost>0?" dim":"");
      const desc=c.isCandle?"Ofrenda · al sacrificarla genera Sangre":c.sigils.slice(0,2).map(s=>D.sigils[s].name).join(" · ");
      d.innerHTML=`<div class="cost ${c.costType}">${cost}${c.costType==="bone"?" H":" S"}</div><div class="hand-art"><img src="${art}" alt=""></div><div class="hand-name">${c.name}</div><div class="hand-desc">${desc}</div><div class="hand-stats"><span>ATQ ${displayAtk(c)}</span><span>VID ${c.maxHp}</span></div>`;
      d.onclick=()=>{
        if(busy||battle.drawPending)return;
        if(!pay&&cost>0){toast(c.costType==="bone"?`Requiere ${cost} Huesos. Las muertes generan Huesos.`:`Requiere ${cost} Sangre. Sacrifica una criatura.`);return}
        selected=selected===i?-1:i;sacrificeMode=false;renderBattle();sfx("click")
      };
      h.appendChild(d)
    })
  }
  function renderContext(){
    const title=$("#contextTitle"),text=$("#contextText");
    if(sacrificeMode){title.textContent="Modo sacrificio";text.textContent="Selecciona una criatura de tu lado. Obtendrás Sangre y 1 Hueso."}
    else if(selected>=0){
      const c=battle.hand[selected];title.textContent=c.name;text.textContent=`Coste: ${effectiveCost(c)} ${c.costType==="bone"?"Huesos":"Sangre"} · Selecciona un carril vacío.`
    }else{title.textContent="Tu turno";text.textContent="Juega cartas, sacrifica si necesitas Sangre o termina el turno."}
    $("#sacrificeBtn").classList.toggle("hidden",!battle.player.some(Boolean)||busy);
    $("#cancelBtn").classList.toggle("hidden",selected<0&&!sacrificeMode)
  }
  $("#sacrificeBtn").onclick=()=>{if(busy)return;sacrificeMode=!sacrificeMode;selected=-1;renderBattle();sfx("click")};
  $("#cancelBtn").onclick=()=>{selected=-1;sacrificeMode=false;renderBattle()};
  $("#endTurnBtn").onclick=resolveTurn;
  $("#drawBeastBtn").onclick=()=>{drawBeast(1);battle.drawPending=false;$("#drawPrompt").classList.add("hidden");renderBattle();sfx("click")};
  $("#drawCandleBtn").onclick=()=>{if(battle.hand.length<handMax())battle.hand.push(candle());battle.drawPending=false;$("#drawPrompt").classList.add("hidden");renderBattle();sfx("click")};

  function onLane(i){
    if(busy||battle.drawPending)return;
    if(sacrificeMode){
      const c=battle.player[i];if(!c)return;
      const el=$("#playerSide").children[i]?.querySelector(".unit-card");if(el){el.classList.add("die");const p=center(el);burst(p.x,p.y,"#b74d54",16)}
      let gain=1;if(run.oath==="butcher"&&!battle.butcherUsed){gain++;battle.butcherUsed=true}
      battle.player[i]=null;battle.blood+=gain;battle.bones++;toast(`+${gain} Sangre · +1 Hueso`);sfx("sac");setTimeout(renderBattle,140);return
    }
    if(selected<0||battle.player[i])return;
    const c=battle.hand[selected],cost=effectiveCost(c);if(!canPay(c))return;
    if(c.costType==="bone")battle.bones-=cost;else battle.blood-=cost;
    if(run.bloodPact && c.costType==="blood" && !c.isCandle && !battle.bloodPactUsed)battle.bloodPactUsed=true;
    battle.played++;
    const played=battle.hand.splice(selected,1)[0];selected=-1;played.hp=played.maxHp;
    if(run.tempGuardian && played.sigils.includes("guardian")){played.maxHp++;played.hp++}
    if(hasRelic("broken_bell")&&cost===1&&!battle.bellUsed){played.atk++;battle.bellUsed=true}
    if(hasRelic("red_thread")&&played.sigils.includes("duet")&&!battle.redThreadUsed){played.maxHp++;played.hp++;battle.redThreadUsed=true}
    battle.player[i]=played;if(played.sigils.includes("echo"))drawBeast(1);
    renderBattle();const el=$("#playerSide").children[i]?.querySelector(".unit-card");if(el){el.classList.add("summon");const p=center(el);burst(p.x,p.y,"#6b9f92",12)}sfx("play")
  }

  async function resolveTurn(){
    if(busy||battle.drawPending)return;busy=true;selected=-1;sacrificeMode=false;renderBattle();
    for(let i=0;i<3;i++){const a=battle.player[i];if(a&&a.sigils.includes("swift")){await attack(a,battle.enemy[i],i,true);checkDeaths()}}
    for(let i=0;i<3;i++){const a=battle.player[i];if(!a||a.sigils.includes("swift"))continue;await attack(a,battle.enemy[i],i,true);checkDeaths()}
    if(checkEnd()){busy=false;return}
    for(let i=0;i<3;i++){const a=battle.enemy[i];if(!a)continue;await attack(a,battle.player[i],i,false);checkDeaths();if(checkEnd()){busy=false;return}}
    resolveVenom();checkDeaths();if(checkEnd()){busy=false;return}
    await bossRule();checkDeaths();if(checkEnd()){busy=false;return}
    for(let i=0;i<3;i++)if(!battle.enemy[i]&&battle.queue[i]){battle.enemy[i]=battle.queue[i];battle.queue[i]=null}
    refillQueue();
    battle.turn++;battle.blood=0;battle.played=0;battle.toothUsed=false;battle.butcherUsed=false;battle.bellUsed=false;battle.redThreadUsed=false;
    battle.player.filter(Boolean).forEach(c=>{c.guardUsed=false;c.wardUsed=false;c.poisoned=false});
    battle.enemy.filter(Boolean).forEach(c=>{c.guardUsed=false;c.wardUsed=false;c.poisoned=false});
    battle.drawPending=true;busy=false;$("#drawPrompt").classList.remove("hidden");renderBattle()
  }
  async function attack(a,d,lane,playerAttack){
    if(!a)return;
    const side=playerAttack?"#playerSide":"#enemySide",el=$(side).children[lane]?.querySelector(".unit-card");if(el)el.classList.add("attack");
    await wait(145);let dmg=displayAtk(a);
    if(d){
      const target=playerAttack?"#enemySide":"#playerSide",tel=$(target).children[lane]?.querySelector(".unit-card");
      if(d.sigils.includes("guardian")&&!d.guardUsed){d.guardUsed=true;dmg=Math.max(0,dmg-2)}
      if(d.sigils.includes("ward")&&!d.wardUsed&&d.hp===d.maxHp&&dmg>=d.hp){d.wardUsed=true;dmg=Math.max(0,d.hp-1)}
      d.hp-=dmg;if(d.sigils.includes("thorns")&&dmg>0)a.hp--;if(a.sigils.includes("venom")&&dmg>0)d.poisoned=true;
      if(tel){tel.classList.add("hit");floatText(tel,"-"+dmg,"#f18b8c");const p=center(tel);burst(p.x,p.y,"#be4e54",8)}sfx("hit")
    }else if(dmg>0){
      let delta=playerAttack?dmg:-dmg;
      if(playerAttack&&hasRelic("ivory_tooth")&&!battle.toothUsed){delta++;battle.toothUsed=true}
      shiftPressure(delta);
      if(playerAttack){
        battle.cadence++;
        if(a.sigils.includes("leech"))battle.blood++;
        if(battle.cadence>=4){
          battle.cadence=0;
          let bonus=hasRelic("fourth_string")?3:2;
          if(run.cadencePact)bonus++;
          if(run.tempCadence && !battle.tempCadenceUsed){bonus++;battle.tempCadenceUsed=true}
          shiftPressure(bonus+(a.sigils.includes("precise")?1:0));showCadenza()
        }
      } else if(battle.boss?.id==="pale_director"){
        battle.enemyCadence=(battle.enemyCadence||0)+1;
        if(battle.enemyCadence>=4){battle.enemyCadence=0;shiftPressure(-2);toast("El Director completa su propia Cadenza.")}
      }
    }
    await wait(100);renderBattle()
  }
  function shiftPressure(d){battle.pressure=Math.max(-9,Math.min(9,battle.pressure+d));floatText($(".pressure-track"),(d>0?"+":"")+d,d>0?"#e9ce97":"#ec7d84")}
  function showCadenza(){const f=$("#cadenzaFlash");f.classList.remove("show");void f.offsetWidth;f.classList.add("show");const p=center($(".pressure-track"));burst(p.x,p.y,"#ddb975",28);sfx("chime")}
  function resolveVenom(){[...battle.player,...battle.enemy].filter(Boolean).forEach(c=>{if(c.poisoned)c.hp=0})}
  function checkDeaths(){
    for(const side of ["player","enemy"]){
      for(let i=0;i<3;i++){
        const c=battle[side][i];if(!c||c.hp>0)continue;
        const enemy=side==="enemy",el=$(enemy?"#enemySide":"#playerSide").children[i]?.querySelector(".unit-card");
        if(el){el.classList.add("die");const p=center(el);burst(p.x,p.y,enemy?"#9d444b":"#b39a71",11)}
        if(enemy){
          if(beastById[c.species])battle.defeated.push(c.species);
          const killer=battle.player[i];
          if(killer){
            killer.kills=(killer.kills||0)+1;if(killer.sigils.includes("hunger"))killer.atk++;
            if(killer.kills>=wakeNeed(killer)){awaken(killer);toast(`${killer.name} ha Despertado.`);if(hasRelic("silver_mirror"))killer.hp=killer.maxHp}
          }
        }
        battle.bones++;
        if(c.sigils.includes("requiem"))shiftPressure(enemy?-1:1);
        const brood=c.sigils.includes("brood");
        if(enemy&&battle.boss?.id==="taxidermist"&&!battle.bossMemory.has(`${i}`)){
          battle.bossMemory.add(`${i}`);const r=clone(c);r.hp=r.maxHp=1;r.atk=1;r.sigils=[];setTimeout(()=>{battle.enemy[i]=r;renderBattle()},200)
        }else{
          battle[side][i]=null;
          if(brood){const w=candle(2);setTimeout(()=>{if(!battle[side][i])battle[side][i]=w;renderBattle()},170)}
        }
      }
    }
  }
  function refillQueue(){
    for(let i=0;i<3;i++)if(!battle.queue[i]&&battle.enemyDeck.length&&Math.random()<(battle.type==="boss"?.82:.56+Math.min(.22,run.depth*.01)))battle.queue[i]=battle.enemyDeck.pop()
  }
  async function bossRule(){
    const b=battle.boss;if(!b)return;
    if(b.id==="silk_mother"&&battle.turn%2===0){const empt=[0,1,2].filter(i=>!battle.queue[i]&&!battle.enemy[i]);if(empt.length){const c=cardFrom("blind_weaver");c.name="Cría de Seda";c.atk=1;c.hp=c.maxHp=2;battle.queue[rand(empt)]=c;toast("La Madre de Seda ocupa un carril.")}}
    if(b.id==="bell_man"){if(battle.player[1])battle.player[1].hp--;if(battle.enemy[1])battle.enemy[1].hp--;toast("La campana atraviesa el carril central.");sfx("chime");await wait(160)}
    if(b.id==="hungry_one"&&battle.bones>battle.lastBones){const e=battle.enemy.filter(Boolean).sort((a,b)=>displayAtk(b)-displayAtk(a))[0];if(e)e.atk++;battle.lastBones=battle.bones}
    if(b.id==="mirror_choir"&&battle.enemy[1]){
      for(const i of [0,2])if(battle.enemy[i]&&battle.enemy[i].copiedTurn!==battle.turn){battle.enemy[i].atk=displayAtk(battle.enemy[1]);battle.enemy[i].copiedTurn=battle.turn}
    }
  }
  function checkEnd(){
    if(battle.pressure>=7){setTimeout(victory,240);return true}
    if(battle.pressure<=-7){setTimeout(runDefeat,240);return true}
    if(!battle.enemy.some(Boolean)&&!battle.queue.some(Boolean)&&!battle.enemyDeck.length){shiftPressure(2);renderBattle();if(battle.pressure>=7){setTimeout(victory,240);return true}}
    return false
  }

  function victory(){
    run.fragments+=battle.type==="alpha"?5:battle.type==="boss"?8:3;
    if(battle.type==="alpha"&&hasRelic("black_ash"))rand(run.deck).kills++;
    if(battle.type==="boss")return bossReward();
    captureReward(battle.type==="alpha")
  }
  function captureReward(alpha){
    let pool=[...new Set(battle.defeated)].filter(x=>beastById[x]);while(pool.length<3)pool.push(rand(D.beasts).id);pool=shuffle(pool).slice(0,3);
    modal("VICTORIA",`<h2>Selecciona una captura</h2><p>Una especie repetida no añade una copia: Despierta a una carta de esa especie. El reparto se profundiza en lugar de inflarse.</p><div id="captureGrid" class="reward-grid"></div><button id="declineCapture" style="width:100%;margin-top:8px">RECHAZAR · +3 FRAGMENTOS</button>`);
    const g=$("#captureGrid");
    for(const id of pool){
      const s=beastById[id],d=document.createElement("div");d.className="choice reward";
      d.innerHTML=`<div class="reward-art"><img src="${s.art}" alt=""></div><div><div class="rarity">${alpha?"CAPTURA ALFA":"CAPTURA"}</div><h3>${s.name}</h3><p>${s.cost} ${s.costType==="bone"?"Huesos":"Sangre"} · ATQ ${s.atk} · VIDA ${s.hp}</p><p>${s.sigils.map(x=>D.sigils[x].name).join(" · ")}</p></div>`;
      d.onclick=()=>{const ex=run.deck.find(c=>c.species===id);if(ex){awaken(ex);if(run.oath==="collector")awaken(ex)}else{const c=cardFrom(id);if(alpha)awaken(c);run.deck.push(c)}closeModal();clearNodeAndReturn()};g.appendChild(d)
    }
    $("#declineCapture").onclick=()=>{run.fragments+=3;closeModal();clearNodeAndReturn()}
  }
  function bossReward(){
    run.bosses++;meta.bestBoss=Math.max(meta.bestBoss||0,run.bosses);persist();
    let picks=shuffle(D.relics.filter(r=>!hasRelic(r.id))).slice(0,3);if(picks.length<3)picks=shuffle(D.relics).slice(0,3);
    modal("FIN DEL ACTO",`<h2>El Guardián cede una regla</h2><p>Las Reliquias mayores modifican todos los Actos posteriores.</p><div id="relicGrid" class="reward-grid"></div>${hasRelic("sealed_program")?'<button id="rejectRelic" style="width:100%;margin-top:8px">RECHAZAR · DESPERTAR DOS CARTAS</button>':""}`);
    const g=$("#relicGrid");
    for(const r of picks){
      const d=document.createElement("div");d.className="choice reward";d.innerHTML=`<div class="reward-art" style="display:grid;place-items:center;font-size:32px">${r.mark}</div><div><div class="rarity">RELIQUIA MAYOR</div><h3>${r.name}</h3><p>${r.text}</p></div>`;
      d.onclick=()=>{run.relics.push(r);closeModal();captureAfterBoss()};g.appendChild(d)
    }
    const reject=$("#rejectRelic");if(reject)reject.onclick=()=>{for(const c of shuffle(run.deck.slice()).slice(0,2))awaken(c);closeModal();captureAfterBoss()}
  }
  function captureAfterBoss(){
    let pool=[...new Set(battle.defeated)].filter(x=>beastById[x]);while(pool.length<3)pool.push(rand(D.beasts).id);const id=rand(pool);
    const ex=run.deck.find(c=>c.species===id);if(ex)awaken(ex);else{const c=cardFrom(id);awaken(c);run.deck.push(c)}
    run.cleared.push("boss");advanceAct()
  }
  function runDefeat(){
    const earned=run.fragments+run.bosses*4+Math.floor(run.depth/3);
    meta.ash=(meta.ash||0)+earned;meta.bestDepth=Math.max(meta.bestDepth||0,run.depth);meta.bestBoss=Math.max(meta.bestBoss||0,run.bosses);persist();
    $("#deathDepth").textContent=run.depth;$("#deathBosses").textContent=run.bosses;$("#deathAsh").textContent="+"+earned;
    $("#deathQuote").textContent=rand(["«Una representación termina en el instante exacto en que deja de obedecerte.»","«No conserves la derrota. Conserva la decisión que la produjo.»","«Las mejores criaturas de una run son precisamente las que no puedes llevarte.»"]);
    show("deathScreen")
  }

  // Events
  function graftEvent(id){
    const donors=shuffle(run.deck.filter(c=>c.sigils.length)).slice(0,3);
    if(!donors.length){run.fragments+=2;return clearNodeAndReturn(id)}
    modal("ANATOMÍA",`<h2>Selecciona el donante</h2><p>La carta elegida será eliminada del reparto. Uno de sus Sigilos podrá transferirse a otra criatura.</p><div id="eventGrid" class="reward-grid"></div>`);
    const g=$("#eventGrid");
    for(const c of donors){
      const d=document.createElement("div");d.className="choice reward";d.innerHTML=`<div class="reward-art"><img src="${beastById[c.species].art}" alt=""></div><div><h3>${c.name}</h3><p>${c.sigils.map(s=>D.sigils[s].name).join(" · ")}</p></div>`;
      d.onclick=()=>chooseGraftHost(c,id);g.appendChild(d)
    }
  }
  function chooseGraftHost(donor,nodeId){
    const sig=rand(donor.sigils),hosts=shuffle(run.deck.filter(c=>c.uid!==donor.uid)).slice(0,4);
    modal("INJERTO · "+D.sigils[sig].name,`<h2>Selecciona el huésped</h2><p>${D.sigils[sig].text}</p><div id="eventGrid" class="reward-grid"></div>`);
    const g=$("#eventGrid");
    for(const h of hosts){
      const d=document.createElement("div");d.className="choice reward";d.innerHTML=`<div class="reward-art"><img src="${beastById[h.species].art}" alt=""></div><div><h3>${h.name}</h3><p>ATQ ${displayAtk(h)} · VIDA ${h.maxHp}</p><p>${h.sigils.map(s=>D.sigils[s].name).join(" · ")}</p></div>`;
      d.onclick=()=>{run.deck.splice(run.deck.indexOf(donor),1);if(!h.sigils.includes(sig))h.sigils.push(sig);if(hasRelic("bone_needle")){h.maxHp++;h.hp=h.maxHp}closeModal();clearNodeAndReturn(nodeId)};g.appendChild(d)
    }
  }
  function campEvent(id){
    const scarred=run.deck.filter(c=>c.scar>0);
    modal("CAMERINO",`<h2>Una pausa entre escenas</h2><div id="eventGrid" class="reward-grid"></div>`);
    const opts=[
      ["Sutura", "Elimina todas las Heridas de una carta.",()=>{if(scarred.length)rand(scarred).scar=0;else run.fragments+=2}],
      ["Ensayo privado","Una carta recibe 2 memorias de baja y puede Despertar.",()=>{const c=rand(run.deck);c.kills+=2;if(c.kills>=wakeNeed(c))awaken(c)}],
      ["Recorte de reparto","Elimina una carta de coste 1 a tu elección.",()=>removeOneCostCard()]
    ];
    const g=$("#eventGrid");
    for(const [name,text,go] of opts){const d=document.createElement("div");d.className="choice";d.innerHTML=`<div class="meta">Camerino</div><h3>${name}</h3><p>${text}</p>`;d.onclick=()=>{go();if(name!=="Recorte de reparto"){closeModal();clearNodeAndReturn(id)}};g.appendChild(d)}
    function removeOneCostCard(){
      const cards=run.deck.filter(c=>c.cost===1);if(!cards.length){run.fragments+=3;closeModal();clearNodeAndReturn(id);return}
      modal("RECORTE DE REPARTO",`<h2>Selecciona una carta</h2><div id="eventGrid" class="reward-grid"></div>`);
      const gg=$("#eventGrid");for(const c of cards){const d=document.createElement("div");d.className="choice reward";d.innerHTML=`<div class="reward-art"><img src="${beastById[c.species].art}" alt=""></div><div><h3>${c.name}</h3><p>Será retirada durante el resto de la run.</p></div>`;d.onclick=()=>{run.deck.splice(run.deck.indexOf(c),1);closeModal();clearNodeAndReturn(id)};gg.appendChild(d)}
    }
  }
  function archiveEvent(id){
    const picks=shuffle(run.deck.slice()).slice(0,3);
    modal("ARCHIVO",`<h2>Elige qué historia conservar</h2><p>La carta seleccionada obtiene 2 memorias de baja. Si alcanza su umbral, Despierta.</p><div id="eventGrid" class="reward-grid"></div>`);
    const g=$("#eventGrid");
    for(const c of picks){const d=document.createElement("div");d.className="choice reward";d.innerHTML=`<div class="reward-art"><img src="${beastById[c.species].art}" alt=""></div><div><h3>${c.name}</h3><p>${c.kills}/${wakeNeed(c)} memorias · Acto ${roman(c.wake||0)}</p><p>${c.lore}</p></div>`;d.onclick=()=>{c.kills+=2;if(c.kills>=wakeNeed(c))awaken(c);closeModal();clearNodeAndReturn(id)};g.appendChild(d)}
  }
  function merchantEvent(id){
    const offers=shuffle(D.beasts).slice(0,2);
    modal("INTERMEDIARIO",`<h2>Intercambio de Fragmentos</h2><p>Fragmentos disponibles: <b>${run.fragments}</b></p><div id="eventGrid" class="reward-grid"></div><button id="leaveMerchant" style="width:100%;margin-top:8px">CONTINUAR</button>`);
    const g=$("#eventGrid");
    for(const s of offers){const cost=5+s.cost*2,d=document.createElement("div");d.className="choice reward";d.innerHTML=`<div class="reward-art"><img src="${s.art}" alt=""></div><div><div class="rarity">${cost} FRAGMENTOS</div><h3>${s.name}</h3><p>ATQ ${s.atk} · VIDA ${s.hp} · ${s.sigils.map(x=>D.sigils[x].name).join(" · ")}</p></div>`;d.onclick=()=>{if(run.fragments<cost)return;run.fragments-=cost;const ex=run.deck.find(c=>c.species===s.id);if(ex)awaken(ex);else run.deck.push(cardFrom(s.id));closeModal();clearNodeAndReturn(id)};g.appendChild(d)}
    const cleanse=document.createElement("div");cleanse.className="choice";cleanse.innerHTML=`<div class="meta">4 Fragmentos</div><h3>Restauración</h3><p>Elimina una Herida aleatoria de tu reparto.</p>`;cleanse.onclick=()=>{if(run.fragments<4)return;const s=run.deck.filter(c=>c.scar);if(!s.length)return;run.fragments-=4;rand(s).scar=0;closeModal();clearNodeAndReturn(id)};g.appendChild(cleanse);
    $("#leaveMerchant").onclick=()=>{closeModal();clearNodeAndReturn(id)}
  }
  function altarEvent(id){
    const opts=[
      ["Sangre anticipada","Tu primera criatura de Sangre en los próximos combates cuesta 1 menos, pero una carta aleatoria recibe una Herida.","bloodPact"],
      ["Osario abierto","Empiezas los próximos combates con +2 Huesos, pero retira una criatura de coste 1 del reparto.","bonePact"],
      ["Cuarto compás","La Cadenza añade +1 Presión durante este Acto, pero los encuentros Alfa comienzan con -2 Presión.","cadencePact"]
    ];
    modal("ALTAR",`<h2>Un pacto siempre modifica dos cosas</h2><div id="eventGrid" class="reward-grid"></div>`);
    const g=$("#eventGrid");
    for(const [name,text,key] of opts){const d=document.createElement("div");d.className="choice";d.innerHTML=`<div class="meta">Pacto</div><h3>${name}</h3><p>${text}</p>`;d.onclick=()=>{run[key]=true;if(key==="bloodPact"){const marked=rand(run.deck);marked.scar=(marked.scar||0)+1;}if(key==="bonePact"){const a=run.deck.filter(c=>c.cost===1);if(a.length)run.deck.splice(run.deck.indexOf(rand(a)),1)}closeModal();clearNodeAndReturn(id)};g.appendChild(d)}
  }
  function omenEvent(id){
    const r=(Math.random()*4)|0;
    if(r===0){
      const c=rand(run.deck);modal("PRESAGIO",`<h2>Un nombre aparece escrito antes de tiempo</h2><p>${c.name} puede Despertar dos veces. A cambio, otra carta aleatoria recibirá dos Heridas.</p><button id="omenYes" class="danger" style="width:100%">ACEPTAR</button><button id="omenNo" style="width:100%;margin-top:8px">RECHAZAR</button>`);$("#omenYes").onclick=()=>{awaken(c);awaken(c);const v=rand(run.deck.filter(x=>x.uid!==c.uid));if(v)v.scar=(v.scar||0)+2;closeModal();clearNodeAndReturn(id)};$("#omenNo").onclick=()=>{closeModal();clearNodeAndReturn(id)}
    }else if(r===1){
      modal("PRESAGIO",`<h2>La cuarta puerta está abierta</h2><p>Puedes perder 6 Fragmentos para recibir una Reliquia mayor aleatoria. Si no tienes suficientes, la puerta permanece cerrada.</p><button id="omenYes" ${run.fragments<6?"disabled":""} style="width:100%">PAGAR 6 FRAGMENTOS</button><button id="omenNo" style="width:100%;margin-top:8px">MARCHARSE</button>`);$("#omenYes").onclick=()=>{if(run.fragments<6)return;run.fragments-=6;const p=D.relics.filter(x=>!hasRelic(x.id));if(p.length)run.relics.push(rand(p));closeModal();clearNodeAndReturn(id)};$("#omenNo").onclick=()=>{closeModal();clearNodeAndReturn(id)}
    }else if(r===2){
      const c=rand(run.deck);modal("PRESAGIO",`<h2>El Curador solicita una ausencia</h2><p>Retira permanentemente a ${c.name}. A cambio, obtienes 10 Fragmentos.</p><button id="omenYes" class="danger" style="width:100%">ENTREGAR LA CARTA</button><button id="omenNo" style="width:100%;margin-top:8px">CONSERVARLA</button>`);$("#omenYes").onclick=()=>{run.deck.splice(run.deck.indexOf(c),1);run.fragments+=10;closeModal();clearNodeAndReturn(id)};$("#omenNo").onclick=()=>{closeModal();clearNodeAndReturn(id)}
    }else{
      modal("PRESAGIO",`<h2>La sala está completamente vacía</h2><p>No ocurre nada visible. Ganas 4 Fragmentos. Una futura escena puede recordar que estuviste aquí.</p><button id="omenYes" style="width:100%">CONTINUAR</button>`);$("#omenYes").onclick=()=>{run.fragments+=4;run.emptyRoom=true;closeModal();clearNodeAndReturn(id)}
    }
  }
  function reliquaryEvent(id){
    const temp=[
      {name:"Aguja Menor",text:"Durante este Acto, tus criaturas con Custodia ganan +1 Vida.",key:"tempGuardian"},
      {name:"Metrónomo Opaco",text:"Durante este Acto, la primera Cadenza de cada combate añade +1 Presión.",key:"tempCadence"},
      {name:"Cáliz de Hueso",text:"Durante este Acto, empiezas cada combate con +1 Hueso.",key:"tempBone"}
    ];
    modal("RELICARIO MENOR",`<h2>Una regla que solo durará este Acto</h2><div id="eventGrid" class="reward-grid"></div><button id="takeFragments" style="width:100%;margin-top:8px">RECHAZAR · +5 FRAGMENTOS</button>`);
    const g=$("#eventGrid");
    for(const t of shuffle(temp).slice(0,2)){const d=document.createElement("div");d.className="choice";d.innerHTML=`<div class="meta">Reliquia de Acto</div><h3>${t.name}</h3><p>${t.text}</p>`;d.onclick=()=>{run[t.key]=true;closeModal();clearNodeAndReturn(id)};g.appendChild(d)}
    $("#takeFragments").onclick=()=>{run.fragments+=5;closeModal();clearNodeAndReturn(id)}
  }

  // Detail / rules / backstage
  function openDeck(){
    const cards=run.deck.slice().sort((a,b)=>(b.wake||0)-(a.wake||0)||a.cost-b.cost);
    modal("REPARTO",`<h2>${cards.length} cartas en la run</h2><div id="deckGrid" class="reward-grid"></div><button id="closeDeck" style="width:100%;margin-top:8px">CERRAR</button>`);
    const g=$("#deckGrid");
    for(const c of cards){const s=beastById[c.species],d=document.createElement("div");d.className="choice reward";d.innerHTML=`<div class="reward-art"><img src="${s.art}" alt=""></div><div><div class="rarity">ACTO ${roman(c.wake||0)} · ${c.kills}/${wakeNeed(c)} MEMORIAS</div><h3>${c.name}</h3><p>ATQ ${displayAtk(c)} · VIDA ${c.maxHp} · ${c.cost} ${c.costType==="bone"?"Huesos":"Sangre"}</p><p>${c.sigils.map(x=>D.sigils[x].name).join(" · ")}</p></div>`;d.onclick=()=>openCardDetail(c);g.appendChild(d)}
    $("#closeDeck").onclick=closeModal
  }
  function openCardDetail(c){
    const s=beastById[c.species];modal(c.name,`<div class="card-detail"><div class="art"><img src="${s.art}" alt="" style="width:100%;height:100%;object-fit:cover"></div><div><h2>${c.name}</h2><p>${c.lore}</p><p><b>ATQ ${displayAtk(c)} · VIDA ${c.maxHp}</b><br>${c.cost} ${c.costType==="bone"?"Huesos":"Sangre"} · ${c.kills}/${wakeNeed(c)} memorias</p></div></div><div class="trait-list">${c.sigils.map(x=>`<div class="trait"><b>${D.sigils[x].name}</b><span>${D.sigils[x].text}</span></div>`).join("")}</div><button id="backDeck" style="width:100%;margin-top:10px">VOLVER</button>`);$("#backDeck").onclick=openDeck
  }
  function openRules(){
    modal("REGLAS",`<h2>El ritual, sin ambigüedad</h2>
      <div class="trait-list">
        <div class="trait"><b>1 · Vela → Sangre</b><span>Empiezas siempre con una Vela de coste 0 y una Bestia de Sangre coste 1. Juega la Vela, activa Sacrificar y tócala. Recibes Sangre y Huesos.</span></div>
        <div class="trait"><b>2 · Sangre y Huesos</b><span>La Sangre solo dura tu turno. Los Huesos permanecen durante el combate y aparecen cuando muere cualquier criatura.</span></div>
        <div class="trait"><b>3 · Presión</b><span>Una criatura que ataca un carril vacío empuja la Presión. Llegar a +7 gana. Llegar a -7 termina inmediatamente la run.</span></div>
        <div class="trait"><b>4 · Cadencia</b><span>Cada cuarto impacto directo activa Cadenza y genera Presión adicional.</span></div>
        <div class="trait"><b>5 · Despertar</b><span>Las bajas pertenecen a esa carta concreta. Al alcanzar su umbral obtiene estadísticas o un nuevo Sigilo.</span></div>
        <div class="trait"><b>6 · Mapa</b><span>Cada run genera un mapa ramificado nuevo. Tras completar un nodo solo puedes continuar por las conexiones dibujadas.</span></div>
      </div><button id="closeRules" style="width:100%;margin-top:10px">CERRAR</button>`);$("#closeRules").onclick=closeModal
  }
  function openBattleHelp(){openRules()}
  function openBackstage(){
    const defs=[
      ["match","Cerilla de Plata",14,"Comienza cada combate con una segunda Vela."],
      ["bone","Falange Tallada",20,"Comienza cada combate con 1 Hueso adicional."],
      ["memory","Programa Anotado",28,"Una criatura inicial comienza cada run con 1 memoria de baja."]
    ];
    modal("CAMERINO PERMANENTE",`<h2>Mementos</h2><p>La Ceniza se conserva entre runs. Los Mementos son mejoras pequeñas y permanentes.</p><div id="mementoGrid" class="reward-grid"></div><button id="closeBackstage" style="width:100%;margin-top:8px">CERRAR</button>`);
    const g=$("#mementoGrid");
    for(const [key,name,cost,text] of defs){
      const owned=meta.mementos[key],d=document.createElement("div");d.className="choice";d.innerHTML=`<div class="meta">${owned?"ADQUIRIDO":cost+" CENIZA"}</div><h3>${name}</h3><p>${text}</p>`;
      if(!owned)d.onclick=()=>{if(meta.ash<cost)return;meta.ash-=cost;meta.mementos[key]=1;persist();openBackstage()};g.appendChild(d)
    }
    $("#closeBackstage").onclick=closeModal
  }

  function scene(eyebrow,title,quote,rule){
    $("#sceneEyebrow").textContent=eyebrow;$("#sceneTitle").textContent=title;$("#sceneQuote").textContent=quote;$("#sceneRule").textContent=rule;
    const s=$("#scene");s.classList.remove("hidden","fade");if(battle?.type==="boss")sfx("boss");setTimeout(()=>s.classList.add("fade"),1200);setTimeout(()=>s.classList.add("hidden"),1780)
  }

  renderMenu();
})();